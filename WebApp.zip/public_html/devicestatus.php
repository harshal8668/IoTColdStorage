<?php
    include("config.php");
	if(isset($_GET['id'])){
		$device_id=$_GET['id'];
		global $dbc;
		$update_query = "select `status` from `status` where `id`=$device_id";
        $q=mysqli_query($conn, $update_query);
// 		$q=mysqli_query($dbc,"select status from status where id='".$device_id."'")or die("Unable to Show Result");
		while($f=mysqli_fetch_assoc($q)){
			echo $f['status'];
		}
	}
?>