<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

    include 'config.php';


// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Query your database and fetch data
$sql = "SELECT * FROM userdata";
$result = $conn->query($sql);

// Prepare the data to send back as JSON
$data = array();
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
}

// Close the connection
$conn->close();

// Send the data back in JSON format
header('Content-Type: application/json');
echo json_encode($data);
?>
