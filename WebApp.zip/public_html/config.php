<?php

$servername='localhost';
$username='id21929004_coldstorage';
$password='ColdStorage@123';
$database='id21929004_coldstorage';

$conn=mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Error".mysqli_connect_error());
}

?>