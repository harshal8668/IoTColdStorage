<?php

$servername = "localhost";
$username='id21929004_coldstorage';
$password='ColdStorage@123';
$dbname='id21929004_coldstorage';
// Create connection
$conn = new mysqli($servername, $username,$password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$seton = $_GET['on'];
$setoff = $_GET['off'];
$id = $_GET['id'];
 

$sql = "UPDATE `timer` SET `ontime`= $seton, `offtime` = $setoff WHERE `id` = $id";
if ($conn->query($sql) === TRUE) {
    // echo "Saved Successfully!";
} else {
    echo "Error:" . $sql . "<br>" . $conn->error;
}

$conn->close();
?>