<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "localhost";
$username='id21929004_coldstorage';
$password='ColdStorage@123';
$dbname='id21929004_coldstorage';
// Create connection
$conn = new mysqli($servername, $username,$password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$temp = $_GET['temp'];
$hum = $_GET['hum'];
$gas = $_GET['gas'];
 
$sql = "INSERT INTO maintainance (temp,hum,gas) VALUES ($temp,$hum,$gas);";
if ($conn->query($sql) === TRUE) {
    // echo "Saved Successfully!";
} else {
    echo "Error:" . $sql . "<br>" . $conn->error;
}

$conn->close();
?>