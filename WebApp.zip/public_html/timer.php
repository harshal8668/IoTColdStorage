<?php
include 'config.php';
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location:index.php");
    exit;
} 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="darkmode.js"></script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Chamber 1</title>

</head>

<body>
    <header>
        <nav class="container">
            <ul class="nav justify-content-end">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="home.php"><img src="Images/home.png" alt=""> Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="logout.php"><img src="Images/profile.png" alt="Home">LogOut</a>
                </li>
                <li class="nav-item darkMode">
                    <input type="checkbox" name="toggle" id="toggle" onclick="ToggleDarkMode()"/>
                    <label for="toggle" id="switch">
                        <div class="Dark"></div>
                        <div class="circle"></div>
                        <div class="Light"></div>
                    </label>
                </li>
            </ul>
        </nav>
    </header>

    <main class="OuterDeviceContainer">
        <h2>Chamber 1</h2>
        <div class="btngrp">
            <button onclick="window.location='control.php'">Controls</button>
            <button onclick="window.location='timer.php'">Timer</button>
            <button onclick="window.location='monitor.php'">Monitor</button>
            <button onclick="window.location='analytics.html'">Analytics</button>
        </div>
        <h5>Timer</h5>
        <p id='valErr'></p>
        <form method="post" class="deviceContainer">
            <div class="deviceCard">
                <h3>Air Conditioner</h3>
                <p>Set on/off time</p>

                <div class="timerform">
                    <input type="number" placeholder="On Time" name="AcOn" id="acon"/>
                    <input type="number" placeholder="Off Time" name="AcOff" id="acoff"/>
                    <button type="submit" name="AcSubmit" id="submit" class='acSubmit' >Submit</button>
                </div>

                <p style="line-height: 7px; margin-top:20px;"  >Current time set</p>
                <p style="line-height: 7px;" id="curr_ac_ontime"></p>
                <p style="line-height: 7px;" id="curr_ac_offtime"></p>

            </div>

            <div class="deviceCard">
                <h3>Gas Valve</h3>
                <p>Set on/off time</p>
                <div class="timerform">
                    <input type="number" placeholder="On Time" name="GasOn" id="gason">
                    <input type="number" placeholder="Off Time" name="GasOff" id="gasoff">
                    <button type="submit" name="GasSubmit" id="submit" class='gasSubmit'>Submit</button>
                </div>
                <p style="line-height: 7px; margin-top:20px;" >Current time set</p>
                <p style="line-height: 7px;"  id="curr_gas_ontime"></p>
                <p style="line-height: 7px;" id="curr_gas_offtime"></p>
            </div>

            <div class="deviceCard">
                <h3>Exhaust Fan</h3>
                <p>Set on/off time</p>
                <div class="timerform">
                    <input type="number" placeholder="On Time" name="FanOn" id="fanon">
                    <input placeholder="Off Time" type="number" class="input" name="FanOff" id="fanoff">
                    <button type="submit" name="FanSubmit" id="submit" class='fanSubmit'>Submit</button>
                </div>
                <p style="line-height: 7px; margin-top:20px;" >Current time set</p>
                <p style="line-height: 7px;"  id="curr_fan_ontime"></p>
                <p style="line-height: 7px;" id="curr_fan_offtime"></p>
            </div>
        </form>
    </main>

    <link rel="stylesheet" href="override.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        window.addEventListener('load', function() {
                <?php
                include 'config.php';
                $ac_query = "SELECT * FROM `timer` WHERE `equipment`='ac'";
                $ac_data = mysqli_query($conn, $ac_query);
                $AC_data = mysqli_fetch_assoc($ac_data);
                $curr_ac_ontime = $AC_data['ontime'];
                $curr_ac_offtime = $AC_data['offtime'];

                $gas_query = "SELECT * FROM `timer` WHERE `equipment`='gas'";
                $gas_data = mysqli_query($conn, $gas_query);
                $GAS_data = mysqli_fetch_assoc($gas_data);
                $curr_gas_ontime = $GAS_data['ontime'];
                $curr_gas_offtime = $GAS_data['offtime'];

                $fan_query = "SELECT * FROM `timer` WHERE `equipment`='fan'";
                $fan_data = mysqli_query($conn, $fan_query);
                $FAN_data = mysqli_fetch_assoc($fan_data);
                $curr_fan_ontime = $FAN_data['ontime'];
                $curr_fan_offtime = $FAN_data['offtime'];
                ?>
                document.getElementById('curr_ac_ontime').innerHTML = `On time: <?php echo $curr_ac_ontime ?> Min`;
                document.getElementById('curr_ac_offtime').innerHTML = `Off time: <?php echo $curr_ac_offtime ?> Min`;

                document.getElementById('curr_gas_ontime').innerHTML = `On time: <?php echo $curr_gas_ontime?> Min`;
                document.getElementById('curr_gas_offtime').innerHTML = `Off time: <?php echo $curr_gas_offtime ?> Min`;

                document.getElementById('curr_fan_ontime').innerHTML = `On time: <?php echo $curr_fan_ontime ?> Min`;
                document.getElementById('curr_fan_offtime').innerHTML = `Off time: <?php echo $curr_fan_offtime ?> Min`;


        });
        
        
        
        function displayUpdating(){

            let i=5;
            const myInterval=setInterval(function() {
                document.getElementById('valErr').innerHTML="Please wait "+ i +" Seconds. Updating....";
                i--;
            }, 1000);
            
            setTimeout(()=>{
                clearInterval(myInterval);
                location.reload();
            },5000);
        }

        document.getElementsByClassName('acSubmit')[0].addEventListener('click',async (e)=>{
            e.preventDefault();
            
            let acon=document.getElementById('acon');
            let acoff=document.getElementById('acoff');
            
            let aconVal=acon.value;
            let acoffVal=acoff.value;
            
            if(aconVal=="" || acoffVal==""){
                document.getElementById('valErr').innerHTML="Please fill both ON and OFF time.";
            }
            else{
                let url="https://api.thingspeak.com/update?api_key=16BD2RV42BA6HC3R&field1="+aconVal+"&field2="+acoffVal;
                await fetch(url, {
                  method: "POST"
                }).then((res)=>{return res.json();}).catch((err)=>{console.log(err);});
                
                
                let url2="https://coldstoragemonitor.000webhostapp.com/timerUpdate.php?on="+aconVal+"&off="+acoffVal+"&id=1";
                await fetch(url2, {
                  method: "POST"
                }).catch((err)=>{
                    console.log(err);
                    document.getElementById('valErr').innerHTML="Error in updating. Try again later.";
                    
                });
                acon.value='';
                acoff.value='';
                
                displayUpdating();
                
                
            }
            
        });
        
        document.getElementsByClassName('gasSubmit')[0].addEventListener('click',async (e)=>{
            e.preventDefault();
            
            let gason=document.getElementById('gason');
            let gasoff=document.getElementById('gasoff');
            
            let gasonVal=gason.value;
            let gasoffVal=gasoff.value;
            
            if(gasonVal=="" || gasoffVal==""){
                document.getElementById('valErr').innerHTML="Please fill both ON and OFF time.";
            }
            else{
                let url="https://api.thingspeak.com/update?api_key=16BD2RV42BA6HC3R&field3="+gasonVal+"&field4="+gasoffVal;
                await fetch(url, {
                  method: "POST"
                }).then((res)=>{return res.json();}).catch((err)=>{console.log(err);});
                
                
                let url2="https://coldstoragemonitor.000webhostapp.com/timerUpdate.php?on="+gasonVal+"&off="+gasoffVal+"&id=2";
                await fetch(url2, {
                  method: "POST"
                }).catch((err)=>{console.log(err);document.getElementById('valErr').innerHTML="Error in updating. Try again later.";});
                gason.value='';
                gasoff.value='';
                displayUpdating();
            }
            
        });
        
        document.getElementsByClassName('fanSubmit')[0].addEventListener('click',async (e)=>{
            e.preventDefault();
            
            let fanon=document.getElementById('fanon');
            let fanoff=document.getElementById('fanoff');
            
            let fanonVal=fanon.value;
            let fanoffVal=fanoff.value;
            
            if(fanonVal=="" || fanoffVal==""){
                document.getElementById('valErr').innerHTML="Please fill both ON and OFF time.";
            }
            else{
                let url="https://api.thingspeak.com/update?api_key=16BD2RV42BA6HC3R&field5="+fanonVal+"&field6="+fanoffVal;
                await fetch(url, {
                  method: "POST"
                }).then((res)=>{return res.json();}).catch((err)=>{console.log(err);});
                
                
                let url2="https://coldstoragemonitor.000webhostapp.com/timerUpdate.php?on="+fanonVal+"&off="+fanoffVal+"&id=3";
                await fetch(url2, {
                  method: "POST"
                }).catch((err)=>{console.log(err);document.getElementById('valErr').innerHTML="Error in updating. Try again later.";});
                fanon.value='';
                fanoff.value='';
                displayUpdating();
            }
            
        });
      
    </script>
</body>

</html>